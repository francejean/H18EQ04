leox graphite (plain - standards and supplementals)

this set contains 50 icons replacing the standard finder folder icons in a cool graphite look with embossed pictorials. it's free for personal, non commercial use. every feedback is appreciated.

icons in this set:
applications, burn folder, classic, desktop, developer, documents, dropbox, generic, group, home, library, movies, music, open folder, pictures, private, public, read only, sites, smart folder, system (apple), users,
amsterdam (xxx logo), backup, bookmarks, code, discs, download, emails & letters, favorites, feeds, fonts, helpful, ideas, manuals, notes, podcasts, podstuff, scheduled, sounds, sync, system (linux), system(windows), toaster, todos, toprated, caution unchecked stuff, uploads, utilities, vintage

this set is available as .icns files (mac) .png files (e.g. linux) and .ico files (windows xp and vista). please feel free to visit icontoaster.com for more free icons and wallpapers. 

copyright © 2008 by icontoaster, used logos or trademarks (e.g. apple logo) belong to their respective owners.
