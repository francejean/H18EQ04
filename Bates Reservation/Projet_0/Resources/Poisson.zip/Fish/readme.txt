Hey everybody!  I think you know the deal with it comes to these readme things.

All contents are copyrighted � to me, Scott Copeland as well as to my company Nimbus Media.

My site:
www.nimbus-media.com

These icons are pretty cool so enjoy them.  HOWEVER, do not use them for personal gain i.e. reputational or monetary or you will be BREAKING THE LAW.  That's right, I said it.

But yeah, if you want to include these in a personal work, however, please ask me for permission first.  That's all I ask. :)