Thank you for downloading the Chakram icon set.

This package is copyrighted � to Scott Copeland.

Do not use this package for monetary or reputational gain.

If you'd like to contact me, please send an email to nimbusmedia@gmail.com

If you're interested in featuring/hosting this package on your own site please contact me before hand to acquire permission.  If I agree to the hosting of this package on your website, do not modify the contents of this package.

Something tells me you didn't even open and read this anyway, too distracted by the icons...

Oh well,
Enjoy them.